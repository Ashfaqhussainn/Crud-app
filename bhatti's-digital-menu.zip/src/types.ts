
export type AppScreen = 'SPLASH' | 'HOME' | 'CATEGORY' | 'MENU_ITEMS' | 'ORDER_SUMMARY' | 'THANK_YOU';

export interface MenuItem {
  id: string;
  name: string;
  category: string;
  price: number;
  description: string;
  image: string;
}

export interface CartItem extends MenuItem {
  quantity: number;
}
