/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ChevronLeft, 
  X, 
  ShoppingBag, 
  Plus, 
  Minus, 
  CheckCircle, 
  ArrowRight,
  UtensilsCrossed,
  Pizza,
  GlassWater,
  IceCream,
  CircleCheck,
  ChevronRight,
  Info
} from 'lucide-react';
import { AppScreen, MenuItem, CartItem } from './types.ts';
import { MENU_ITEMS, CATEGORIES } from './constants.tsx';

// --- Global UI Components (Mimicking Android) ---

const Toast = ({ message, onClear }: { message: string, onClear: () => void }) => {
  useEffect(() => {
    const timer = setTimeout(onClear, 2000);
    return () => clearTimeout(timer);
  }, [onClear]);

  return (
    <motion.div
      initial={{ y: 50, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      exit={{ y: 50, opacity: 0 }}
      className="fixed bottom-24 left-1/2 -translate-x-1/2 bg-slate-800 text-white px-6 py-3 rounded-full shadow-2xl z-[100] text-sm font-medium border border-slate-700 whitespace-nowrap"
      id="toast-message"
    >
      {message}
    </motion.div>
  );
};

const AlertDialog = ({ title, message, onConfirm, onCancel }: { title: string, message: string, onConfirm: () => void, onCancel: () => void }) => {
  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-[110] p-4">
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className="bg-white rounded-3xl overflow-hidden max-w-sm w-full shadow-2xl"
      >
        <div className="p-8">
          <h3 className="text-2xl font-black text-slate-900 mb-2">{title}</h3>
          <p className="text-slate-500 font-medium leading-relaxed">{message}</p>
        </div>
        <div className="flex border-t border-slate-100">
          <button 
            onClick={onCancel}
            className="flex-1 py-5 text-slate-400 font-bold hover:bg-slate-50 transition-colors uppercase tracking-widest text-xs"
          >
            No
          </button>
          <button 
            onClick={onConfirm}
            className="flex-1 py-5 text-red-500 font-bold hover:bg-red-50 transition-colors border-l border-slate-100 uppercase tracking-widest text-xs"
          >
            Yes
          </button>
        </div>
      </motion.div>
    </div>
  );
};

// --- App Screen Components ---

const SplashScreen = ({ onFinish }: { onFinish: () => void }) => {
  useEffect(() => {
    const timer = setTimeout(onFinish, 2000);
    return () => clearTimeout(timer);
  }, [onFinish]);

  return (
    <motion.div 
      initial={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-orange-500 flex flex-col items-center justify-center z-50 p-6"
      id="splash-screen"
    >
      <motion.div
        initial={{ scale: 0.5, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ type: "spring", stiffness: 100 }}
        className="bg-white p-8 rounded-[3rem] shadow-2xl mb-8"
      >
        <UtensilsCrossed className="w-20 h-20 text-orange-500" />
      </motion.div>
      <motion.h1 
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.3 }}
        className="text-white text-4xl font-black tracking-tight"
      >
        Bhatti's Kitchen
      </motion.h1>
      <motion.p 
        initial={{ opacity: 0 }}
        animate={{ opacity: 0.7 }}
        transition={{ delay: 0.5 }}
        className="text-white mt-4 font-mono uppercase tracking-[0.2em] text-xs"
      >
        Digital Menu v1.0
      </motion.p>
    </motion.div>
  );
};

export default function App() {
  const [screen, setScreen] = useState<AppScreen>('SPLASH');
  const [cart, setCart] = useState<CartItem[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string>('');
  const [toast, setToast] = useState<string | null>(null);
  const [alert, setAlert] = useState<{ title: string, message: string, onConfirm: () => void } | null>(null);

  const showToast = (msg: string) => setToast(msg);
  
  const addToCart = (item: MenuItem) => {
    setCart(prev => {
      const existing = prev.find(i => i.id === item.id);
      if (existing) {
        return prev.map(i => i.id === item.id ? { ...i, quantity: i.quantity + 1 } : i);
      }
      return [...prev, { ...item, quantity: 1 }];
    });
    showToast(`${item.name} added to order`);
  };

  const removeFromCart = (id: string) => {
    setCart(prev => prev.filter(i => i.id !== id));
  };

  const updateQuantity = (id: string, delta: number) => {
    setCart(prev => prev.map(item => {
      if (item.id === id) {
        const newQty = Math.max(1, item.quantity + delta);
        return { ...item, quantity: newQty };
      }
      return item;
    }));
  };

  const cartTotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);

  const resetOrder = () => {
    setCart([]);
    setScreen('HOME');
  };

  const getCategoryIcon = (cat: string) => {
    switch (cat) {
      case 'Burgers': return <motion.div whileHover={{rotate: 15}}><UtensilsCrossed className="text-orange-500" /></motion.div>;
      case 'Pizza': return <motion.div whileHover={{rotate: -15}}><Pizza className="text-red-500" /></motion.div>;
      case 'Drinks': return <motion.div whileHover={{scale: 1.1}}><GlassWater className="text-blue-500" /></motion.div>;
      case 'Desserts': return <motion.div whileHover={{y: -5}}><IceCream className="text-pink-500" /></motion.div>;
      default: return <Info />;
    }
  };

  const navigateTo = (newScreen: AppScreen, extra?: any) => {
    if (extra && typeof extra === 'string') {
      setSelectedCategory(extra);
    }
    setScreen(newScreen);
  };

  if (screen === 'SPLASH') return <SplashScreen onFinish={() => setScreen('HOME')} />;

  return (
    <div className="min-h-screen bg-slate-100 flex items-center justify-center p-0 sm:p-4 font-sans select-none overflow-hidden">
      <AnimatePresence>
        {toast && <Toast message={toast} onClear={() => setToast(null)} />}
        {alert && <AlertDialog {...alert} onCancel={() => setAlert(null)} />}
      </AnimatePresence>

      <div className="w-full max-w-sm h-[100dvh] sm:h-[800px] bg-white sm:rounded-[3rem] shadow-2xl overflow-hidden relative flex flex-col border border-slate-200">
        
        {/* Android Style Header */}
        {screen !== 'HOME' && screen !== 'THANK_YOU' && (
          <header className="px-6 h-20 flex items-center justify-between border-b border-slate-50 sticky top-0 bg-white/80 backdrop-blur-md z-40">
            <div className="flex items-center gap-4">
              <button 
                onClick={() => {
                   if (screen === 'CATEGORY') navigateTo('HOME');
                   else if (screen === 'MENU_ITEMS') navigateTo('CATEGORY');
                   else if (screen === 'ORDER_SUMMARY') navigateTo('MENU_ITEMS');
                }}
                className="w-12 h-12 rounded-2xl hover:bg-slate-50 flex items-center justify-center transition-all bg-slate-50 border border-slate-100"
                id="back-button"
              >
                <ChevronLeft className="w-6 h-6 text-slate-800" />
              </button>
              <h2 className="font-black text-slate-900 tracking-tight text-xl">
                {screen === 'CATEGORY' ? 'Categories' : screen === 'MENU_ITEMS' ? selectedCategory : 'Your Order'}
              </h2>
            </div>
            {cart.length > 0 && screen !== 'ORDER_SUMMARY' && (
              <button 
                onClick={() => navigateTo('ORDER_SUMMARY')}
                className="relative w-12 h-12 bg-orange-100 rounded-2xl flex items-center justify-center text-orange-600 transition-transform active:scale-90"
              >
                <ShoppingBag className="w-6 h-6" />
                <span className="absolute -top-1 -right-1 w-5 h-5 bg-orange-500 text-white text-[10px] font-black rounded-full flex items-center justify-center ring-2 ring-white">
                  {cart.length}
                </span>
              </button>
            )}
          </header>
        )}

        {/* Content Area (ScrollView Layout) */}
        <div className="flex-1 overflow-y-auto no-scrollbar pb-32">
          <AnimatePresence mode="wait">
            
            {/* Screen 1: Home Activity */}
            {screen === 'HOME' && (
              <motion.div 
                key="home-screen"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="h-full flex flex-col p-10 justify-between items-center bg-gradient-to-b from-white to-orange-50"
              >
                <div className="w-full text-center mt-12">
                  <div className="w-24 h-24 bg-orange-500 rounded-[2rem] flex items-center justify-center mx-auto mb-8 shadow-2xl shadow-orange-500/30">
                     <UtensilsCrossed className="w-12 h-12 text-white" />
                  </div>
                  <h1 className="text-4xl font-black text-slate-900 leading-tight mb-4">
                    Delicious Food,<br/><span className="text-orange-500">Fast Delivery.</span>
                  </h1>
                  <p className="text-slate-500 font-bold">Discover the best flavors from Bhatti's Kitchen delivered to your seat.</p>
                </div>

                <div className="w-full space-y-6">
                  <div className="bg-white/80 backdrop-blur p-6 rounded-3xl border border-white shadow-sm flex items-center gap-4">
                    <div className="w-12 h-12 bg-green-100 rounded-2xl flex items-center justify-center text-green-600">
                      <CheckCircle className="w-6 h-6" />
                    </div>
                    <div>
                      <p className="text-xs uppercase font-black tracking-widest text-slate-400">Status</p>
                      <p className="text-slate-800 font-bold">Restaurant is Open</p>
                    </div>
                  </div>
                  
                  <motion.button
                    whileTap={{ scale: 0.95 }}
                    onClick={() => navigateTo('CATEGORY')}
                    className="w-full py-6 bg-orange-500 text-white rounded-3xl font-black text-xl shadow-xl shadow-orange-500/30 flex items-center justify-center gap-3 active:bg-orange-600 transition-colors"
                    id="view-menu-btn"
                  >
                    View Menu <ArrowRight className="w-6 h-6" />
                  </motion.button>
                </div>
              </motion.div>
            )}

            {/* Screen 2: Category Activity */}
            {screen === 'CATEGORY' && (
              <motion.div 
                key="category-screen"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="p-6"
              >
                <div className="mb-8">
                  <h3 className="text-2xl font-black text-slate-900">Choose a Category</h3>
                  <p className="text-slate-500 font-bold">What are you craving today?</p>
                </div>

                <div className="grid grid-cols-2 gap-4" id="category-grid">
                  {CATEGORIES.map((cat) => (
                    <motion.button
                      key={cat}
                      whileHover={{ y: -5 }}
                      whileTap={{ scale: 0.95 }}
                      onClick={() => navigateTo('MENU_ITEMS', cat)}
                      className="aspect-square bg-white border-2 border-slate-50 p-6 rounded-[2.5rem] shadow-sm hover:shadow-xl hover:border-orange-100 transition-all flex flex-col justify-between items-start"
                    >
                      <div className="w-14 h-14 bg-slate-50 rounded-2xl flex items-center justify-center text-3xl">
                        {getCategoryIcon(cat)}
                      </div>
                      <div>
                        <h4 className="font-black text-slate-800 text-lg leading-none mb-1">{cat}</h4>
                        <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">
                          {MENU_ITEMS.filter(m => m.category === cat).length} Items
                        </p>
                      </div>
                    </motion.button>
                  ))}
                </div>
              </motion.div>
            )}

            {/* Screen 3: Menu Activity (Items List) */}
            {screen === 'MENU_ITEMS' && (
              <motion.div 
                key="menu-items-screen"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="p-6"
              >
                <div className="space-y-6">
                  {MENU_ITEMS.filter(m => m.category === selectedCategory).map((item) => (
                    <motion.div
                      layout
                      key={item.id}
                      className="bg-white border-2 border-slate-50 rounded-[2rem] p-5 shadow-sm hover:shadow-md transition-all flex gap-4 items-center"
                    >
                      <div className="relative">
                        <img 
                          src={item.image} 
                          alt={item.name} 
                          className="w-24 h-24 rounded-2xl object-cover shadow-inner"
                          referrerPolicy="no-referrer"
                        />
                        <div className="absolute -top-2 -right-2 bg-orange-500 text-white text-[10px] font-black px-2 py-1 rounded-lg">
                          NEW
                        </div>
                      </div>
                      <div className="flex-1">
                        <h4 className="font-black text-slate-900 leading-tight">{item.name}</h4>
                        <p className="text-xs font-bold text-slate-400 mt-1 mb-2 leading-tight">{item.description}</p>
                        <div className="flex items-center justify-between">
                          <span className="font-black text-orange-500 text-lg">Rs. {item.price}</span>
                          <motion.button
                            whileTap={{ scale: 0.9 }}
                            onClick={() => addToCart(item)}
                            className="w-10 h-10 bg-slate-900 text-white rounded-xl flex items-center justify-center shadow-lg active:bg-orange-500 transition-colors"
                          >
                            <Plus className="w-5 h-5" />
                          </motion.button>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </motion.div>
            )}

            {/* Screen 4: Order Summary Activity */}
            {screen === 'ORDER_SUMMARY' && (
              <motion.div 
                key="order-summary-screen"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                className="p-6"
              >
                {cart.length === 0 ? (
                  <div className="h-full flex flex-col items-center justify-center py-20 text-center">
                    <div className="w-20 h-20 bg-slate-50 rounded-full flex items-center justify-center mb-6">
                      <ShoppingBag className="w-10 h-10 text-slate-300" />
                    </div>
                    <h3 className="text-xl font-black text-slate-900">Your bag is empty</h3>
                    <p className="text-slate-400 font-bold mt-2">Add some delicious items to start an order!</p>
                    <button 
                      onClick={() => navigateTo('CATEGORY')}
                      className="mt-8 text-orange-500 font-black uppercase tracking-widest text-xs border-b-2 border-orange-500 pb-1"
                    >
                      Explore Menu
                    </button>
                  </div>
                ) : (
                  <div className="space-y-6">
                    <div className="space-y-4">
                      {cart.map(item => (
                        <motion.div 
                          layout
                          key={item.id}
                          className="flex items-center gap-4 bg-slate-50 p-4 rounded-2xl border border-slate-100"
                        >
                          <img 
                            src={item.image} 
                            alt={item.name} 
                            className="w-16 h-16 rounded-xl object-cover"
                            referrerPolicy="no-referrer"
                          />
                          <div className="flex-1">
                            <h5 className="font-black text-slate-800 text-sm leading-tight">{item.name}</h5>
                            <p className="text-orange-500 font-black text-xs mt-1">Rs. {item.price}</p>
                          </div>
                          <div className="flex items-center gap-3 bg-white px-3 py-2 rounded-xl shadow-sm border border-slate-100">
                            <button onClick={() => updateQuantity(item.id, -1)} className="text-slate-400"><Minus className="w-4 h-4" /></button>
                            <span className="font-black text-sm text-slate-900 w-4 text-center">{item.quantity}</span>
                            <button onClick={() => updateQuantity(item.id, 1)} className="text-slate-900"><Plus className="w-4 h-4" /></button>
                          </div>
                          <button onClick={() => removeFromCart(item.id)} className="text-slate-300 hover:text-red-500 px-1">
                            <X className="w-5 h-5" />
                          </button>
                        </motion.div>
                      ))}
                    </div>

                    <div className="bg-slate-900 p-8 rounded-[2.5rem] text-white shadow-2xl mt-10">
                      <div className="space-y-4 mb-8">
                        <div className="flex justify-between text-slate-400 font-bold text-sm">
                          <span>Subtotal</span>
                          <span>Rs. {cartTotal}</span>
                        </div>
                         <div className="flex justify-between text-slate-400 font-bold text-sm">
                          <span>Service Fee</span>
                          <span>Rs. 50</span>
                        </div>
                        <div className="h-px bg-slate-800 my-2" />
                        <div className="flex justify-between text-2xl font-black">
                          <span>Total</span>
                          <span className="text-orange-400">Rs. {cartTotal + 50}</span>
                        </div>
                      </div>
                      
                      <motion.button
                        whileTap={{ scale: 0.95 }}
                        onClick={() => {
                          setAlert({
                            title: "Confirm Order",
                            message: "Placement of this order is permanent. Are you sure you're ready to eat?",
                            onConfirm: () => {
                              setAlert(null);
                              navigateTo('THANK_YOU');
                            }
                          });
                        }}
                        className="w-full py-5 bg-orange-500 rounded-2xl font-black text-lg shadow-lg active:bg-orange-600 transition-colors flex items-center justify-center gap-3"
                        id="confirm-order-btn"
                      >
                        Place Order <CircleCheck className="w-6 h-6" />
                      </motion.button>
                    </div>
                  </div>
                )}
              </motion.div>
            )}

            {/* Screen 5: Thank You Activity */}
            {screen === 'THANK_YOU' && (
              <motion.div 
                key="thank-you-screen"
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="h-full flex flex-col items-center justify-center p-10 text-center"
              >
                <div className="w-32 h-32 bg-green-100 rounded-[3rem] flex items-center justify-center mb-8 shadow-inner">
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ type: "spring", delay: 0.2 }}
                  >
                    <CheckCircle className="w-16 h-16 text-green-500" />
                  </motion.div>
                </div>
                <h1 className="text-4xl font-black text-slate-900 mb-4">Order Confirmed!</h1>
                <p className="text-slate-500 font-bold leading-relaxed mb-12">
                  Thank you for your order. Our kitchen team is already preparing your delicious meal.
                </p>
                <div className="bg-slate-50 w-full p-6 rounded-3xl border border-slate-100 mb-12">
                   <p className="text-xs uppercase font-black tracking-[.25em] text-slate-400 mb-1">Order #</p>
                   <p className="text-slate-800 font-black text-xl">BK-2026-9923</p>
                </div>
                <motion.button
                  whileTap={{ scale: 0.95 }}
                  onClick={resetOrder}
                  className="w-full py-5 bg-slate-900 text-white rounded-2xl font-black tracking-widest text-xs uppercase"
                  id="back-home-btn"
                >
                  Back to Home
                </motion.button>
              </motion.div>
            )}

          </AnimatePresence>
        </div>

        {/* Global Navigation Hint (Android UI Footer style) */}
        {screen !== 'HOME' && screen !== 'THANK_YOU' && screen !== 'ORDER_SUMMARY' && cart.length > 0 && (
           <motion.div 
            initial={{ y: 100 }}
            animate={{ y: 0 }}
            className="absolute bottom-0 left-0 right-0 p-6 bg-white/80 backdrop-blur-xl border-t border-slate-100 z-50 flex items-center justify-between"
           >
              <div>
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Selected Items</p>
                <p className="text-slate-900 font-black">Rs. {cartTotal}</p>
              </div>
              <button 
                onClick={() => navigateTo('ORDER_SUMMARY')}
                className="px-8 py-4 bg-slate-900 text-white rounded-2xl font-black text-sm shadow-xl active:bg-slate-700 transition-colors flex items-center gap-2"
              >
                View Cart <ChevronRight className="w-4 h-4" />
              </button>
           </motion.div>
        )}
      </div>
    </div>
  );
}


