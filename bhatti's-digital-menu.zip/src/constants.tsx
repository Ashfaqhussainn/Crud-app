import { MenuItem } from './types.ts';

export const MENU_ITEMS: MenuItem[] = [
  // Burgers
  {
    id: 'b1',
    name: 'Zinger Burger',
    category: 'Burgers',
    price: 450,
    description: 'Crispy chicken fillet with lettuce and mayo.',
    image: 'https://images.unsplash.com/photo-1571091718767-18b5c1457add?w=800&auto=format&fit=crop&q=60'
  },
  {
    id: 'b2',
    name: 'Cheese Beef Burger',
    category: 'Burgers',
    price: 600,
    description: 'Double beef patty with melted cheddar.',
    image: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=800&auto=format&fit=crop&q=60'
  },
  // Pizza
  {
    id: 'p1',
    name: 'Margherita Pizza',
    category: 'Pizza',
    price: 800,
    description: 'Classic tomato and mozzarella with fresh basil.',
    image: 'https://images.unsplash.com/photo-1604382354936-07c5d9983bd3?w=800&auto=format&fit=crop&q=60'
  },
  {
    id: 'p2',
    name: 'Pepperoni Pizza',
    category: 'Pizza',
    price: 1100,
    description: 'Loaded with beef pepperoni and extra cheese.',
    image: 'https://images.unsplash.com/photo-1628840042765-356cda07504e?w=800&auto=format&fit=crop&q=60'
  },
  // Drinks
  {
    id: 'd1',
    name: 'Iced Coffee',
    category: 'Drinks',
    price: 350,
    description: 'Chilled espresso with fresh milk and ice.',
    image: 'https://images.unsplash.com/photo-1517701604599-bb29b565090c?w=800&auto=format&fit=crop&q=60'
  },
  {
    id: 'd2',
    name: 'Mango Smoothie',
    category: 'Drinks',
    price: 300,
    description: 'Fresh mangoes blended with yogurt.',
    image: 'https://images.unsplash.com/photo-1623065422902-30a2ad44924b?w=800&auto=format&fit=crop&q=60'
  },
  // Desserts
  {
    id: 's1',
    name: 'Chocolate Brownie',
    category: 'Desserts',
    price: 250,
    description: 'Warm fudgy brownie with chocolate chips.',
    image: 'https://images.unsplash.com/photo-1624353365286-3f8d62daad51?w=800&auto=format&fit=crop&q=60'
  },
  {
    id: 's2',
    name: 'Classic Cheesecake',
    category: 'Desserts',
    price: 400,
    description: 'New York style cheesecake with berry coulis.',
    image: 'https://images.unsplash.com/photo-1533134242443-d4fd215305ad?w=800&auto=format&fit=crop&q=60'
  }
];

export const CATEGORIES = ['Burgers', 'Pizza', 'Drinks', 'Desserts'];
